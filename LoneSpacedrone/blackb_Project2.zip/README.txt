LONE SPACEDRONE
BY BRET BLACK

ALL ART HAS BEEN ORIGINALLY DRAWN.

Controls:
ASWD: Fire Lasers
Arrow Keys: Movement
Spacebar: Sonic Boom

The goal of the game is to survive as long as possible.  The game ends when you either run out of lives or if the space station is completely destroyed.

As you kill aliens and destroy astroids, you will gain resources and experience.  When the experience bar is full, you will gain a level, increasing your range, health,
and engine power.  Additional lives are awarded on every 5th level.

Resources can be spent on repairing the space station.  To repair the station, fire your laser on it.

The observatories on the edge of the screen will randomly spawn resource packs and health boosters.  Fire your lasers to collect them.